const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Almacenar sesiones en memoria
const sessions = {};

// Servir archivos estáticos
app.use(express.static('public'));

// Ruta principal
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Rutas de sesión
app.get('/session/:sessionId', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// WebSocket - Socket.IO
io.on('connection', (socket) => {
  console.log('Nuevo usuario conectado:', socket.id);

  // Cuando un usuario se une a una sesión
  socket.on('join_session', (data) => {
    const { sessionId, participantName } = data;
    
    // Crear sesión si no existe
    if (!sessions[sessionId]) {
      sessions[sessionId] = {
        participants: {},
        responses: {
          pasion: [],
          habilidad: [],
          valor: [],
          sustento: []
        }
      };
    }

    // Registrar participante
    socket.join(sessionId);
    sessions[sessionId].participants[socket.id] = {
      name: participantName,
      socketId: socket.id
    };

    // Enviar datos existentes al nuevo usuario
    socket.emit('load_data', {
      responses: sessions[sessionId].responses,
      participantCount: Object.keys(sessions[sessionId].participants).length
    });

    // Notificar a todos que alguien se conectó
    io.to(sessionId).emit('update_participants', {
      count: Object.keys(sessions[sessionId].participants).length,
      participants: sessions[sessionId].participants
    });

    console.log(`${participantName} se unió a la sesión ${sessionId}`);
  });

  // Cuando se agrega una respuesta
  socket.on('add_response', (data) => {
    const { sessionId, quadrant, text, author } = data;

    if (sessions[sessionId]) {
      const response = {
        text: text,
        author: author,
        timestamp: Date.now()
      };

      sessions[sessionId].responses[quadrant].push(response);

      // Enviar a todos en la sesión
      io.to(sessionId).emit('response_added', {
        quadrant: quadrant,
        response: response,
        allResponses: sessions[sessionId].responses
      });

      console.log(`Nueva respuesta en ${quadrant}: ${text}`);
    }
  });

  // Cuando se desconecta
  socket.on('disconnect', () => {
    // Limpiar de todas las sesiones
    Object.keys(sessions).forEach(sessionId => {
      if (sessions[sessionId].participants[socket.id]) {
        delete sessions[sessionId].participants[socket.id];

        // Notificar
        io.to(sessionId).emit('update_participants', {
          count: Object.keys(sessions[sessionId].participants).length,
          participants: sessions[sessionId].participants
        });

        // Si no hay más participantes, limpiar sesión
        if (Object.keys(sessions[sessionId].participants).length === 0) {
          delete sessions[sessionId];
        }
      }
    });

    console.log('Usuario desconectado:', socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Servidor Ikigai Mentor corriendo en puerto ${PORT}`);
});