# 🚀 IKIGAI MENTOR - GUÍA DE DEPLOYMENT

## ¿Qué acabamos de crear?

Un servidor **Node.js con Socket.IO** que permite:
- ✅ Sincronización en **tiempo real**
- ✅ Todos los participantes ven **al instante** lo que escriben los demás
- ✅ Un **único link** compartible para cada taller
- ✅ Nube de palabras actualizada en **vivo**

---

## 📋 PASO 1: Preparar los archivos

Ya tenés:
- `server.js` - El servidor
- `public/index.html` - La app que todos usan
- `package.json` - Las dependencias

Crea una carpeta llamada `ikigai-mentor` y mete estos 3 archivos adentro.

---

## 🌐 PASO 2: Deployar en Render (GRATIS)

### 2.1 Crear cuenta en Render
1. Entra a **https://render.com**
2. Click en "Sign Up" → "Sign up with GitHub" (o email)
3. Completa el registro

### 2.2 Conectar GitHub
1. En Render, click en tu avatar → "Settings"
2. Click en "GitHub" → "Connect Account"
3. Autoriza Render a acceder a tu GitHub

### 2.3 Crear un repositorio en GitHub
1. Ve a **https://github.com/new**
2. Nombre: `ikigai-mentor`
3. Descripción: "Sincronización en tiempo real para talleres de mentoría"
4. Click "Create repository"

### 2.4 Subir los archivos
Desde tu computadora (necesitás Git instalado):

```bash
cd ikigai-mentor
git init
git add .
git commit -m "Inicial"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/ikigai-mentor.git
git push -u origin main
```

(Reemplaza `TU_USUARIO` con tu username de GitHub)

### 2.5 Deployar en Render
1. En Render, click en "New +" → "Web Service"
2. Click en "Connect a repository" → Selecciona `ikigai-mentor`
3. Configuración:
   - **Name**: `ikigai-mentor`
   - **Environment**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free (gratuito)
4. Click "Create Web Service"

Espera 5-10 minutos a que termine el deployment. 🎉

---

## 📱 PASO 3: Usar la app

Una vez desplegada, Render te da una URL como:
```
https://ikigai-mentor-xxxxx.onrender.com
```

### Para cada taller:
1. **Comparte un link único**:
   ```
   https://ikigai-mentor-xxxxx.onrender.com/session/mi-taller-2026
   ```
   (Reemplaza `mi-taller-2026` con el nombre de tu taller)

2. Todos los participantes entran a ese link
3. Escriben su nombre
4. Empiezan a agregar aportes
5. **TODOS VEN EN VIVO** lo que escriben los demás

### Para descargar el resultado:
Click en "Descargar imagen" al final

---

## ⚡ Notas importantes

- **Gratuito**: Render te da 750 horas/mes gratis (suficiente para talleres)
- **Offline**: Si pasan días sin usar, la app se pausa (se reactiva cuando alguien entra)
- **Datos**: Se pierden al reiniciar el servidor (eso es intencional para privacidad)
- **Links únicos**: Cada URL (session/nombre-diferente) es una sesión nueva

---

## 🔧 Si algo no funciona

**Problema**: "La app no abre"
- Espera 5 minutos después del deployment
- Refresh la página (Cmd+R o Ctrl+R)

**Problema**: "No veo las respuestas de otros"
- Verifica que todos estén en el **mismo link**
- Comprueba que el servidor está "Running" en Render

**Problema**: "¿Cómo reinicio el servidor?"
- En Render, en tu servicio, click en "Manual Deploy" → "Deploy latest commit"

---

## 🎯 Customizaciones posibles

Si en el futuro querés cambiar:
- Los colores de los cuadrantes
- El tamaño del canvas
- Agregar más cuadrantes

Me lo contás y lo ajustamos fácil. El código está todo limpio para modificar.

---

**¿Necesitás ayuda?** Escribime cuando hayas completado los pasos.
